# 启动手册

## 如何设置以及启动项目

### 集成后端

修改`vue.config.js`文件:

```shell script
# 修改服务端地址, 与你的服务端地址对应
const host = 'http://127.0.0.1:56010'
```

如果上面的配置不生效, 修改文件`.env`:

```shell script
# 修改服务端地址, 与你的服务端地址对应
VUE_APP_BASE_API = 'http://127.0.0.1:56010'
```

### 启动

```shell script
# 安装yarn
sudo npm i yarn tyarn -g

# 安装依赖
yarn install

# 运行工程(自带热部署)
yarn serve

# 构建生产环境(自带压缩)
yarn build

# 代码格式检查以及自动修复
yarn lint
```
